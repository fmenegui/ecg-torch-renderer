# Desempenho do gerador 0.2.1

A integração on the fly funciona em software, incluindo `nn.Sequential`, geração de uma nova captura por chamada, `autocast`, backward da CNN, passo do otimizador e retomada de checkpoint. A execução CUDA e sua velocidade ainda não foram medidas. Este ambiente oferece PyTorch 2.14.1+cpu, sem GPU. Portanto, a execução CPU não comprova a velocidade nem a memória de uma placa CUDA.

## Medidas realizadas

O benchmark executou o `forward` público de `ECGImageLayer` com sinais artificiais de 12 derivações, 10 segundos e 500 Hz, perfil `mixed`, severidade 0,6 e preservação de extremos. Foram 3 aquecimentos e 10 lotes por caso, com 2 threads CPU. Os presets alteram dimensões, antialiasing, resolução da superfície, iterações inversas e amostras de sombra. A leitura do sinal, transferência, preparação inicial das fontes, codificação PNG/JPEG e CNN ficam fora da medição. A simulação de artefatos JPEG dentro do renderizador está incluída.

| Preset | Largura × altura | Antialias | Superfície | Iterações | Amostras de sombra | CPU B=1, mediana | CPU B=1, imagens/s | CPU B=4, mediana do lote | CPU B=4, imagens/s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| fast | 384 × 256 | 1 | 32 | 3 | 0 | 49,3 ms | 20,18 | 163,5 ms | 24,14 |
| balanced | 512 × 384 | 2 | 64 | 3 | 2 | 110,4 ms | 8,94 | 482,6 ms | 8,41 |
| full | 1024 × 768 | 4 | 96 | 5 | 8 | 639,8 ms | 1,54 | 4763,1 ms | 0,88 |

Vazão usa número de imagens dividido pela soma dos tempos, não o inverso da mediana. São amostras curtas de um único host. No modo full, o lote maior piorou a vazão CPU. Não extrapole esse comportamento como resultado CUDA. Os valores completos, P90, configurações e hashes estão em `PERFORMANCE_GPU_CPU.json`.

## Caminho de execução e gargalos

O forward usa operações PyTorch no dispositivo dos sinais. O atlas de fontes é inicializado uma vez e move com o módulo. Não há codificação de arquivos ou passagem por PIL/NumPy no forward. A taxa padrão fica em buffer e o RNG por dispositivo é reutilizado. `stage='image'`, usado pela camada, evita reter a supervisão densa. `torch.no_grad()` evita guardar um grafo de backward do renderizador. A CNN subsequente continua treinável.

Essas propriedades permitem execução CUDA, mas não demonstram uma implementação totalmente otimizada. O traçado ainda calcula distância a segmentos em toda a página para cada grupo de derivações e cada amostra de antialiasing. Isso produz muitos intermediários. O perfil CPU identificou `_curves`, deformação do papel e desfoque como os maiores custos no modo full. O perfil foi executado separadamente da medição de latência. As regiões podem ser aninhadas e seus tempos não devem ser somados como partes independentes.

| Preset, B=4 | Chamadas ATen | Volume acumulado de novos storages | Pico visível de storages temporários |
|---|---:|---:|---:|
| fast | 4263 | 1,67 GB | 105 MiB |
| balanced | 4941 | 4,10 GB | 210 MiB |
| full | 6557 | 23,59 GB | 840 MiB |

O volume acumulado representa alocações ao longo do forward, não memória simultaneamente ocupada. Não é tráfego de DRAM medido. O pico CPU considera storages visíveis de resultados ATen com aliases únicos, exclui sinais e buffers constantes e não inclui workspaces internos de convolução/BLAS, fragmentação ou reservas do allocator. Ele não é medição de VRAM. Chamadas ATen incluem views e não equivalem à contagem de kernels CUDA.

A documentação do PyTorch explica que operações pointwise no modo eager frequentemente são limitadas por memória e que fusão pode reduzir acessos e lançamentos. `torch.compile` é uma possibilidade a verificar por bloco, mas não foi usado nem validado neste gerador. O RNG, os sorteios e o gerenciamento de estado exigem cuidado ao compilar ou capturar grafos.

## Estimativa condicional para GPU

Para planejamento, construí um modelo simplificado com lote 4. Ele usa o volume acumulado observado como proxy, multiplica esse volume por 2 a 4 para representar leituras/escritas, assume largura de banda efetiva de 100 a 400 GB/s e acrescenta 15 a 90 ms por lote para despacho Python e lançamentos. Essas hipóteses não foram medidas neste código em CUDA.

`tempo_lote_ms = volume_bytes × multiplicador / (banda_GB_s × 1e9) × 1000 + despacho_ms`

| Preset, B=4 | Tempo estimado do lote | Faixa de planejamento |
|---|---:|---:|
| fast | 23 a 157 ms | 26 a 171 imagens/s |
| balanced | 36 a 254 ms | 16 a 113 imagens/s |
| full | 133 a 1034 ms | 4 a 30 imagens/s |

Essas faixas são cenários de engenharia, não benchmarks, garantias ou previsões para uma placa específica. O desempenho real pode ficar fora delas. Cache, workspace, convolução agrupada, transferências, contenção com a CNN e overhead do host podem alterar bastante o resultado. Como referência de escala, a NVIDIA publica 1008 GB/s de banda máxima para a RTX 4090. A banda efetiva deste gerador não foi medida e não deve ser igualada a esse máximo. As faixas acima assumem apenas 100 a 400 GB/s efetivos.

No modo full, 100 mil imagens consumiriam aproximadamente 0,9 a 7,2 horas de geração sob essas hipóteses. Repetir a geração durante 50 épocas de 100 mil imagens soma aproximadamente 46 a 359 horas. Esses valores excluem CNN, dados e comunicação e não representam tempo de treinamento observado.

O custo por passo depende da CNN. Na execução sequencial atual, `tempo_passo ≈ geração + CNN + dados`. Uma CNN hipotética que consome 100 ms por lote, combinada com a geração full estimada de 133 a 1034 ms, produz passos de 233 a 1134 ms antes de carregar dados. Não há pipeline com streams sobrepostos implementada ou medida.

## Memória e resolução para treino

Uma imagem full RGB float32 ocupa 9 MiB. A saída de B=32 ocupa 288 MiB. Os temporários do renderizador, os alvos e a CNN exigem memória adicional. `stage='all'`, cena e máscaras por instância não entram nas estimativas acima e custam mais. Não há comprovação de que um lote 32 cabe em 24 GB junto com uma rede real.

Use `ECGImageLayer` ou `stage='image'` para classificação. Para digitalização supervisionada, peça apenas a supervisão necessária à etapa, por exemplo `stage='geometry'` ou `stage='trace'`. Não reduza resolução apenas para aumentar imagens/s sem verificar preservação de QRS, ondas pequenas, grade e separação entre traçados. O preset fast não oferece a mesma observabilidade espacial do full. O envelope preserva extremos por coluna, mas não recupera informação perdida por baixa resolução ou oclusão.

## Correção de AMP e ensaio de treino

A versão anterior falhava dentro de `autocast` CPU bfloat16 devido à mistura de tipos em `lerp` após o desfoque. A versão 0.2.1 mantém a renderização em float32 e devolve o controle de precisão mista à CNN. Não aplique `.half()` ao renderizador. Use `.to(device)` ou `.cuda()` e AMP na rede de imagem.

```python
import torch
from torch import nn
from ecg_gpu import ECGImageLayer, RenderConfig

device = 'cuda'
images = ECGImageLayer(fs=500, config=RenderConfig(height=384, width=512)).to(device)
cnn = nn.Sequential(nn.Conv2d(3, 16, 5, stride=4), nn.ReLU(),
    nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(16, 2)).to(device)
pipeline = nn.Sequential(images, cnn)
optimizer = torch.optim.AdamW(cnn.parameters())
scaler = torch.amp.GradScaler('cuda')

# O DataLoader deve fornecer signals_cuda [B,12,T] em mV e classes_cuda.
optimizer.zero_grad(set_to_none=True)
with torch.autocast('cuda', dtype=torch.float16):
    logits = pipeline(signals_cuda)
    loss = nn.functional.cross_entropy(logits, classes_cuda)
scaler.scale(loss).backward()
scaler.step(optimizer)
scaler.update()
```

O ensaio executado em CPU usou sinais artificiais `[2,12,5000]`, uma CNN mínima, AMP bfloat16, gradientes finitos e alteração dos pesos após o otimizador. Isso verifica a integração, sem demonstrar qualidade clínica, exatidão da reconstrução ou velocidade de uma CNN de produção. O treinador completo foi verificado separadamente com sinais artificiais, partições e retomada de checkpoint. O relatório da versão registra esses resultados.

## Medir a placa de treinamento

No pacote instalado:

```bash
ecg-renderer-audit --device cuda --out audit-cuda \
  --presets fast balanced full --batches 1 4 --steps 50 --warmup 10
```

No projeto:

```bash
python -m scripts.audit_gpu_renderer --device cuda --out audit-cuda \
  --presets fast balanced full --batches 1 4 --steps 50 --warmup 10
```

O audit sincroniza CUDA antes/depois do forward, usa CUDA Events, informa pico alocado e testa um passo AMP. Perfil e ledger ficam fora da medição. Use os lotes do treino após conferir memória, sem começar por B=32 em full. Depois meça o passo completo com a CNN e o DataLoader reais. Sem GPU, o comando falha explicitamente e nunca rotula resultado CPU como CUDA.

## Próximas otimizações justificadas pelo perfil

As prioridades são rasterizar somente regiões próximas ao traçado, fundir distância/cobertura/envelope em menos kernels, reutilizar temporários e verificar compilação de blocos com formas fixas. Cada mudança precisa preservar extremos estreitos, cruzamentos, máscaras, escala temporal/amplitude e replay. Streams para sobreposição e CUDA Graphs exigem medição e controle da sequência aleatória. Esses itens são oportunidades identificadas, não recursos já implementados.

Os exemplos desta auditoria foram gerados pelo código com sinais inteiramente artificiais. Não representam exames de pacientes nem avaliação independente de realismo.

Referências primárias:

- PyTorch, Performance Tuning Guide: https://docs.pytorch.org/tutorials/recipes/recipes/tuning_guide
- PyTorch, CUDA semantics: https://docs.pytorch.org/docs/stable/notes/cuda.html
- NVIDIA, Ada GPU Architecture: https://images.nvidia.com/aem-dam/Solutions/geforce/ada/nvidia-ada-gpu-architecture.pdf
